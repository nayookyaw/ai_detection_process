def printerr(defname, e):
    print("%s : %s" % (defname, e))