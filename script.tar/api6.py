from flask import Flask, jsonify, request
from flask_restful import Api, Resource
import mysql.connector
import json

app = Flask(__name__)
#Flask is a Constructor
api = Api(app)
#Api is a Constructor


##########Function ###################################
def readconfigfile(filename):
    myfile = open(filename)
    x = myfile.readlines()

    lfile = []
    dictfile = {}
    num = 0

    for i in x:
        x[num] = i.rstrip("\n")
        z1 = x[num].split("=")
        z2 = tuple(z1)
        lfile.insert(num, z2) 
        num += 1

    for x, y in lfile:
        dictfile.update({x: y})

    myfile.close()
    return dictfile 

def checkPostedData(postedData, functionName):
    if (functionName == "DateSearch"):
        if "min_datetime" not in postedData or "max_datetime" not in postedData or "filter" not in postedData or "select_cat" not in postedData:
            return 301 #Missing parameter
        else:
            return 200
    elif (functionName == "Threshold"):
        if "min_datetime" not in postedData or "max_datetime" not in postedData or "threshold" not in postedData:
            return 301  # Missing parameter
        else:
            return 200
    elif (functionName == "ViewConfig"):
        if "view_data" not in postedData:
            return 301  # Missing parameter
        else:
            return 200

def QuerySQL(x, y, filter_cat, select_cat):

    config_param = readconfigfile('config.txt')

    mydb = mysql.connector.connect(
        host = config_param.get("DBServerIPAddress"),
        user=config_param["DBUsername"],
        passwd = 'P@ssw0rd',
        database = str(config_param["DatabaseName"])
    )


    #Create Statement

    SQLString = ("SELECT Folder_A_meta.uuid_meta,Folder_A_meta.file_ts,Folder_B_meta.filepath, Folder_D_meta.predict_json FROM Folder_A_meta RIGHT JOIN Folder_D_meta ON Folder_A_meta.uuid_meta=Folder_D_meta.uuid_meta RIGHT JOIN Folder_B_meta ON Folder_A_meta.uuid_meta=Folder_B_meta.uuid_meta WHERE Folder_A_meta.file_ts >= \"{}\" AND Folder_A_meta.file_ts <= \"{}\"".format(x,y))
    mycursor = mydb.cursor()
    mycursor.execute(SQLString)

    data = mycursor.fetchall()

    i = 0
    ListDictOfWord = []
    ReturnCat = []
    for retData in data:
        field = ["uuid_meta", "file_ts", "filepath", "predict_json"]
        # Convert the DateTimetoString
        retData1 = list(retData)

        #print(retData1) 
        retData1[1] = str(retData1[1])
        #Convert the Predicted Result to Dictionary Format
        retData1[3] = json.loads(retData1[3])
        # ZIP the Field and Data
        zipObj = zip(field, retData1)
        # Convert the zipObj to Dictionary
        dictOfWord = dict(zipObj)

        # Convert to JSON Format
        ListDictOfWord.append(dictOfWord)
        ReturnCat.append(findcat(dictOfWord, select_cat))


    if filter_cat == "Yes":
        #print("filter_cat: TRUE")
        json_ReturnCat = json.dumps(ReturnCat, indent=4, sort_keys=False)
        #print(json_ReturnCat)
        # return jsonify(json_ReturnCat)
        return json_ReturnCat
     
    else:
    # Convert the Final Result to JSON
        json_item = json.dumps(ListDictOfWord, indent=4, sort_keys=False)
        print("filter_cat: FALSE")
        #print(json_item)
        return json_item
       # return jsonify(json_item)
    cursor.close()
    connection.close()

def findcat(dictOfWord, select_cat):
    # ----------Decide the Category

    #a = json.loads(dictOfWord["predict_json"])
    a = dictOfWord["predict_json"]

    scoring = a["predictions"][0]["scores"]
    c = max(scoring)

    category = a["predictions"][0]["labels"][scoring.index(c)]
    if (select_cat !="None"):
        if (select_cat == category):
            retCat = {
            "uuid_meta": dictOfWord["uuid_meta"],
            "file_ts": dictOfWord["file_ts"],
            "filepath": dictOfWord["filepath"],
            "Category": category,
            "Score": c
            }
            json_retCat = retCat
            return json_retCat
        elif (select_cat == "All"):
            f=0
        else:
            retCat = {
            }
            json_retCat = retCat

            return json_retCat
    else:
        retCat = {
        }
        json_retCat = retCat
        return json_retCat

    retCat = {
            "uuid_meta": dictOfWord["uuid_meta"],
            "file_ts": dictOfWord["file_ts"],
            "filepath": dictOfWord["filepath"],
            "Category": category,
            "Score": c
            }
    json_retCat = retCat
    return json_retCat

    ###  Decide the Category---END


def QuerySQL_Threshold(x, y, threshold_val):

    config_param = readconfigfile('config.txt')

    mydb = mysql.connector.connect(
        host=str(config_param["DBServerIPAddress"]),
        user=str(config_param["DBUsername"]),
        passwd='P@ssw0rd',
        database=str(config_param["DatabaseName"])
    )


    #Create Statement
    SQLString = ("SELECT Folder_A_meta.uuid_meta,Folder_A_meta.file_ts,Folder_B_meta.filepath, Folder_D_meta.predict_json FROM Folder_A_meta RIGHT JOIN Folder_D_meta ON Folder_A_meta.uuid_meta=Folder_D_meta.uuid_meta RIGHT JOIN Folder_B_meta ON Folder_A_meta.uuid_meta=Folder_B_meta.uuid_meta WHERE Folder_A_meta.file_ts >= \"{}\" AND Folder_A_meta.file_ts <= \"{}\"".format(x,y))

    mycursor = mydb.cursor()
    mycursor.execute(SQLString)

    data = mycursor.fetchall()

    i = 0
    ListDictOfWord = []
    ReturnCat = []
    for retData in data:
        field = ["uuid_meta", "file_ts", "filepath", "predict_json"]
        # Convert the DateTimetoString
        retData1 = list(retData)
        retData1[1] = str(retData1[1])
        # ZIP the Field and Data
        retData1[3] = json.loads(retData1[3])
        zipObj = zip(field, retData1)
        # Convert the zipObj to Dictionary
        dictOfWord = dict(zipObj)
        #print(dictOfWord)

        Threshold_dictofWord = {
            "uuid_meta": dictOfWord["uuid_meta"],
            "file_ts": dictOfWord["file_ts"],
            "filepath": dictOfWord["filepath"],
            "Label_Score":filter_threshold(dictOfWord,  threshold_val),
        }

        ListDictOfWord.append(Threshold_dictofWord)

    # Convert the Final Result to JSON
    print("--------------------json_item")
    #print(ListDictOfWord)
    json_item = json.dumps(ListDictOfWord, indent=4)
    print(json_item)

    #print("FALSE")
    #print(json_item)
    return json_item
       # return jsonify(json_item)
    #cursor.close()
    #connection.close()


def filter_threshold(dictOfWord,  threshold_val):
    # Decide the Category

    a = dictOfWord["predict_json"]
    scoring = a["predictions"][0]["scores"]
    i = 0
    for x in scoring:
        #compare with threshold
        if float(scoring[i]) <= float(threshold_val): 
            p=a["predictions"][0]["scores"]
            q=a["predictions"][0]["labels"]
            p[i]=8888
        else:
            p=""
            q=""  
            dummy = 0
        i += 1

    zip_a = zip(q,p)
    dict_a = dict(zip_a)
    dict_a_nz = {x:y for x,y in dict_a.items() if y!=8888}
    json_retCat = dict_a_nz
    return json_retCat



##########Classes ###################################
class DateSearch(Resource):
    def post(self):
        #Split name of the CCTV from config.txt
        config_param = readconfigfile('config.txt')
        cctvname = config_param["CCTVName"]
        cctvname_split = list(cctvname.split("_"))
        #print(cctvname_split)
        cctvname_split_name = cctvname_split[0]
        cctvname_split_mode = cctvname_split[1]
        cctvname_split_dict = {}
        cctvname_split_dict.update({"cctv_name":cctvname_split_name})
        cctvname_split_dict.update({"cctv_mode":cctvname_split_mode})
        #print(json.loads(cctvname_split_dict))

        # Step 1: Get posted data:
        filter_cat = "No"
        #select_cat = "All"
        postedData = request.get_json()
        #print(str(postedData["select_cat"]))
        status_code = checkPostedData(postedData,"DateSearch")
        # Get the Data from CLIENT Call
        if (status_code != 200):
            retJson = {
                "Message": "An error happened",
                "Status Code":status_code
            }
            return jsonify(retJson)
        x = str(postedData["min_datetime"])
        y = str(postedData["max_datetime"])
        filter_cat = str(postedData["filter"])
        if (postedData["select_cat"] == ""):
            select_cat = "All"
        else:
            select_cat = str(postedData["select_cat"])
        # Search and Return the Result
        RetResult = json.loads(QuerySQL(x, y, filter_cat, select_cat))
        #return jsonify(RetResult)
        print("----Final Result----------")
        print(json.dumps(RetResult, indent = 4, sort_keys = False))
        #Convert the List to Dictionary:
        item_index = 1
        JsonRetResult = {}
        JsonRetResult.update(cctvname_split_dict)
        for item in RetResult:
            JsonRetResult.update({str(item_index):item})
            item_index += 1
        #return JsonRetResult
        print("------------------JSONRET")
        print(type(JsonRetResult))
        print(JsonRetResult)
 
        return jsonify(JsonRetResult)

class Threshold(Resource):
    def post(self):
        #Split name of the CCTV from config.txt
        config_param = readconfigfile('config.txt')
        cctvname = config_param["CCTVName"]
        cctvname_split = list(cctvname.split("_"))
        #print(cctvname_split)
        cctvname_split_name = cctvname_split[0]
        cctvname_split_mode = cctvname_split[1]
        cctvname_split_dict = {}
        cctvname_split_dict.update({"cctv_name":cctvname_split_name})
        cctvname_split_dict.update({"cctv_mode":cctvname_split_mode})
        #print(json.loads(cctvname_split_dict))

        # Step 1: Get posted data:
        filter_cat = "No"
        #select_cat = "All"
        postedData = request.get_json()
        #print(str(postedData["threshold"]))
        status_code = checkPostedData(postedData,"Threshold")
        # Get the Data from CLIENT Call
        print(status_code)
        if (status_code != 200):
            retJson = {
                "Message": "An error happened",
                "Status Code":status_code
            }
            return jsonify(retJson)
        x = str(postedData["min_datetime"])
        y = str(postedData["max_datetime"])

        if (float(postedData["threshold"]) >= 0) and (float(postedData["threshold"]) <=1):
            threshold_val = str(postedData["threshold"])
        else:
            retJson = {
                "Message": "Error Entering Threshold"
            }
            return jsonify(retJson)
        # Search and Return the Result
        RetResult1 = (QuerySQL_Threshold(x, y, threshold_val))
        RetResult = json.loads(RetResult1)
        item_index = 1
        JsonRetResult = {}
        JsonRetResult.update(cctvname_split_dict)
        
        for item in RetResult:
            JsonRetResult.update({str(item_index):item})
            item_index += 1
        
        item_index = 1
        JsonRetResult = {}
        JsonRetResult.update(cctvname_split_dict)
        for item in RetResult:
            JsonRetResult.update({str(item_index):item})
            item_index += 1
        #print ("-------------JsonRetResult") 
        print (JsonRetResult)
        
        return jsonify(JsonRetResult)

class ViewConfig(Resource):
    def post(self):
        postedData = request.get_json()
        status_code = checkPostedData(postedData, "ViewConfig")
        # Get the Data from CLIENT Call
        print(status_code)
        if (status_code != 200):
            retJson = {
                "Message": "An error happened",
                "Status Code": status_code
            }
            return jsonify(retJson)
        if postedData["view_data"] == "Yes":
            config_param = readconfigfile('config.txt')
            return jsonify(config_param)
        else:
            no_view = {
                 "Data": "NONE"
            }
            return jsonify(no_view)

##########Add Resources ###################################
api.add_resource(DateSearch, "/datesearch")
api.add_resource(Threshold, "/threshold")
api.add_resource(ViewConfig, "/viewconfig")


if __name__=="__main__":
    app.run(host='192.168.0.62',debug=True)







