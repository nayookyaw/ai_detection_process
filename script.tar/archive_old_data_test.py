import datetime
import time
import os
import pymysql
import pymysql.cursors
from pymysql.constants import CLIENT
from mysqlDb import connectdb
from readconfig import DirOriginalImage,DirCheckedImage,DirBase64JSON,DirPredictionJSON,DirBackupOriginalImage,DirOriginalImageArch,DirCheckedImageArch,DirBase64JSONArch,DirPredictionJSONArch,DirBackupOriginalImageArch,PeriodMoveToArchive,PeriodDeleteFromArchive
import readconfig

def connectdb_execmany():
  try:
    mydb = pymysql.connect(
    host=readconfig.DBServerIPAddress,
    user=readconfig.DBUsername,
    password=readconfig.DBPassword,
    db=readconfig.DatabaseName,
    cursorclass=pymysql.cursors.DictCursor,
    client_flag=CLIENT.MULTI_STATEMENTS
    )
    return mydb
  except Exception as e:
    print(f"Archiving data failing with error : {e}")


def archive_on_db():
  try:
    mydb = connectdb_execmany()

##Moving all rows older than 30 days to archive tables

    mycursor = mydb.cursor()
    sql1 = "start transaction;insert into cctv_archivedb.Folder_A_arc select * from cctv_metadb.Folder_A_meta where file_ts < date_sub(now(),interval "+int(PeriodMoveToArchive)+" day); delete from cctv_metadb.Folder_A_meta where file_ts < date_sub(now(),interval "+int(PeriodMoveToArchive)+" day);commit;"
    sql2 = "start transaction;insert into cctv_archivedb.Folder_B_arc select * from cctv_metadb.Folder_B_meta where file_ts < date_sub(now(),interval "+int(PeriodMoveToArchive)+" day); delete from cctv_metadb.Folder_B_meta where file_ts < date_sub(now(),interval "+int(PeriodMoveToArchive)+" day);commit;"
    sql3 = "start transaction;insert into cctv_archivedb.Folder_C_arc select * from cctv_metadb.Folder_C_meta where file_ts < date_sub(now(),interval "+int(PeriodMoveToArchive)+" day); delete from cctv_metadb.Folder_C_meta where file_ts < date_sub(now(),interval "+int(PeriodMoveToArchive)+" day);commit;"
    sql4 = "start transaction;insert into cctv_archivedb.Folder_D_arc select * from cctv_metadb.Folder_D_meta where file_ts < date_sub(now(),interval "+int(PeriodMoveToArchive)+" day); delete from cctv_metadb.Folder_D_meta where file_ts < date_sub(now(),interval "+int(PeriodMoveToArchive)+" day);commit;"

    mycursor.execute(sql1) 
    mycursor.execute(sql2)
    mycursor.execute(sql3)
    mycursor.execute(sql4)

## Deleting all rows in archive tables older than 2 years


    sql5 = "delete from cctv_archivedb.Folder_A_arc where file_ts < date_sub(now(),interval "+int(PeriodDeleteFromArchive)+" day);commit;"
    sql6 = "delete from cctv_archivedb.Folder_B_arc where file_ts < date_sub(now(),interval "+int(PeriodDeleteFromArchive)+" day);commit;"
    sql7 = "delete from cctv_archivedb.Folder_C_arc where file_ts < date_sub(now(),interval "+int(PeriodDeleteFromArchive)+" day);commit;"
    sql8 = "delete from cctv_archivedb.Folder_D_arc where file_ts < date_sub(now(),interval "+int(PeriodDeleteFromArchive)+" day);commit;"

    mycursor.execute(sql5)
    mycursor.execute(sql6)
    mycursor.execute(sql7)
    mycursor.execute(sql8)

    mycursor.close


#archive_on_db()
